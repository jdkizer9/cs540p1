//
//  Node.cpp
//  XML Parser
//
//

#include "Node.hpp"

namespace xml {
    
    Node::~Node() {}
}